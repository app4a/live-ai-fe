"use strict";
/**
 * Chat Capture Content Script
 * Auto-detects the live streaming platform and initializes the appropriate adapter.
 *
 * Supported platforms:
 * - Naver Shopping Live (shoppinglive.naver.com)
 * - YouTube Live (youtube.com/watch, youtube.com/live, youtube.com/live_chat)
 * - Localhost (for testing)
 */
const CHAT_EXTENSION_VERSION = '1.0.0';
// ============================================================
// Base Adapter (shared utilities)
// ============================================================
class BaseChatAdapter {
    constructor() {
        this.observer = null;
        this.processedMessages = new Set();
        this.messageCount = 0;
        this.intervals = [];
    }
    cleanup() {
        if (this.observer) {
            this.observer.disconnect();
            this.observer = null;
        }
        for (const timer of this.intervals) {
            window.clearInterval(timer);
        }
        this.intervals = [];
        this.processedMessages.clear();
        this.messageCount = 0;
        console.log(`[${this.platform}] Observer stopped`);
    }
    sendMessage(message) {
        this.messageCount++;
        console.log(`[${this.platform}][${this.messageCount}] ${message.username}: ${message.text}`);
        this.patchDebugStats({
            detectedCount: 1,
            lastDetectedAt: new Date().toISOString(),
        });
        chrome.runtime.sendMessage({
            type: 'chat_message',
            username: message.username,
            text: message.text,
            platform: this.platform,
        }, (response) => {
            if (chrome.runtime.lastError) {
                this.patchDebugStats({
                    sendFailedCount: 1,
                    lastError: chrome.runtime.lastError.message || '메시지 전송 실패',
                });
                return;
            }
            if (response?.success) {
                this.patchDebugStats({
                    sentCount: 1,
                    lastSentAt: new Date().toISOString(),
                    lastError: '',
                });
            }
            else if (response?.error === '선택한 모니터링 탭이 아닙니다' ||
                response?.error === '모니터링 탭을 먼저 선택해주세요') {
                // Expected when multiple live tabs are open and this tab is not selected in popup.
                return;
            }
            else {
                this.patchDebugStats({
                    sendFailedCount: 1,
                    lastError: response?.error || '메시지 전송 실패',
                });
            }
        });
        // Notify popup of detected platform
        chrome.storage.local.set({ detectedPlatform: this.platform });
    }
    isDuplicate(username, text, elementKey) {
        const messageId = elementKey || this.toMessageId(username, text);
        if (this.processedMessages.has(messageId)) {
            this.patchDebugStats({ duplicateCount: 1 });
            return true;
        }
        this.processedMessages.add(messageId);
        // Limit stored message IDs to prevent memory leak
        if (this.processedMessages.size > 1000) {
            const firstId = this.processedMessages.values().next().value;
            if (firstId)
                this.processedMessages.delete(firstId);
        }
        return false;
    }
    rememberExistingMessage(username, text, elementKey) {
        if (!text)
            return;
        const messageId = elementKey || this.toMessageId(username, text);
        this.processedMessages.add(messageId);
        if (this.processedMessages.size > 1000) {
            const firstId = this.processedMessages.values().next().value;
            if (firstId)
                this.processedMessages.delete(firstId);
        }
    }
    toMessageId(username, text) {
        return `${username}:${text}`;
    }
    patchDebugStats(delta) {
        chrome.storage.local.get(['debugContent'], (result) => {
            const prev = (result.debugContent || {});
            chrome.storage.local.set({
                debugContent: {
                    detectedCount: (prev.detectedCount || 0) + (delta.detectedCount || 0),
                    sentCount: (prev.sentCount || 0) + (delta.sentCount || 0),
                    sendFailedCount: (prev.sendFailedCount || 0) + (delta.sendFailedCount || 0),
                    duplicateCount: (prev.duplicateCount || 0) + (delta.duplicateCount || 0),
                    lastDetectedAt: delta.lastDetectedAt ?? prev.lastDetectedAt,
                    lastSentAt: delta.lastSentAt ?? prev.lastSentAt,
                    lastError: delta.lastError ?? prev.lastError,
                },
            });
        });
    }
    async waitForElement(selectors, timeoutMs = 30000) {
        return new Promise((resolve, reject) => {
            const startTime = Date.now();
            const check = () => {
                for (const selector of selectors) {
                    const el = document.querySelector(selector);
                    if (el) {
                        console.log(`[${this.platform}] Found container: ${selector}`);
                        resolve(el);
                        return;
                    }
                }
                if (Date.now() - startTime > timeoutMs) {
                    reject(new Error(`[${this.platform}] Container not found after ${timeoutMs}ms`));
                    return;
                }
                setTimeout(check, 1000);
            };
            check();
        });
    }
}
// ============================================================
// Naver Shopping Live Adapter
// ============================================================
class NaverAdapter extends BaseChatAdapter {
    constructor() {
        super(...arguments);
        this.platform = 'naver';
        this.normalCommentSelector = '[class*="NormalComment_wrap"]';
        this.nicknameSelector = '[class*="NormalComment_nickname"]';
        this.commentSelector = '[class*="NormalComment_comment"]';
        // Naver chat rows can stream in asynchronously on initial page load.
        // Keep a short bootstrap window to register existing rows without sending them.
        this.bootstrapSuppressUntil = 0;
    }
    canRunOnUrl(url) {
        if (url.includes('shoppinglive.naver.com'))
            return true;
        try {
            const parsed = new URL(url);
            return parsed.pathname.includes('test-naver-chat');
        }
        catch {
            return false;
        }
    }
    getBootstrapSuppressSeconds() {
        return new Promise((resolve) => {
            chrome.storage.local.get(['naverBootstrapSuppressSeconds'], (result) => {
                const raw = result.naverBootstrapSuppressSeconds;
                const seconds = Number.isFinite(raw) ? Number(raw) : 5;
                resolve(Math.max(0, Math.min(20, seconds)));
            });
        });
    }
    async init() {
        console.log('[naver] Initializing Naver Shopping Live adapter...');
        const bootstrapSuppressSeconds = await this.getBootstrapSuppressSeconds();
        this.bootstrapSuppressUntil = Date.now() + bootstrapSuppressSeconds * 1000;
        console.log(`[naver] Bootstrap suppression window: ${bootstrapSuppressSeconds}s`);
        const containerSelectors = [
            '[class*="ChattingWrapper"]',
            '[class*="CommentList_wrap"]',
            '[class*="CommentList_scroll"]',
            '[class*="CommentList"]',
            '.live_chat_area',
            '[class*="chat"]',
        ];
        try {
            const container = await this.waitForElement(containerSelectors);
            this.seedExistingMessages(container);
            this.startObserver(container);
        }
        catch (err) {
            console.error(`[naver] Failed to initialize:`, err);
        }
    }
    seedExistingMessages(container) {
        const messages = container.querySelectorAll(this.normalCommentSelector);
        if (messages.length > 0) {
            console.log(`[naver] Seeded ${messages.length} existing messages (skip on load)`);
            messages.forEach((msg) => {
                const row = msg;
                const rowKey = row.getAttribute('data-message-id') || row.id || undefined;
                const username = row.querySelector(this.nicknameSelector)?.textContent?.trim() ||
                    row.querySelector('.user_name, [class*="user"]')?.textContent?.trim() ||
                    'Anonymous';
                const text = row.querySelector(this.commentSelector)?.textContent?.trim() ||
                    row.querySelector('.message_text')?.textContent?.trim() ||
                    '';
                this.rememberExistingMessage(username, text, rowKey);
            });
        }
    }
    startObserver(container) {
        this.observer = new MutationObserver((mutations) => {
            for (const mutation of mutations) {
                if (mutation.type === 'childList') {
                    mutation.addedNodes.forEach((node) => {
                        if (node.nodeType === Node.ELEMENT_NODE) {
                            const rows = this.extractMessageRows(node);
                            rows.forEach((row) => this.processElement(row));
                        }
                    });
                }
            }
        });
        this.observer.observe(container, { childList: true, subtree: true });
        console.log('[naver] Observer started');
        // Fallback polling for pages where mutation events are missed by virtualization.
        const pollId = window.setInterval(() => {
            const rows = container.querySelectorAll(this.normalCommentSelector);
            rows.forEach((row) => this.processElement(row));
        }, 1200);
        this.intervals.push(pollId);
    }
    extractMessageRows(node) {
        const rows = [];
        if (node.matches(this.normalCommentSelector)) {
            rows.push(node);
        }
        node.querySelectorAll(this.normalCommentSelector).forEach((el) => rows.push(el));
        return rows;
    }
    processElement(element) {
        try {
            if (!element.matches(this.normalCommentSelector))
                return;
            const username = element.querySelector(this.nicknameSelector)?.textContent?.trim() ||
                element.querySelector('.user_name, [class*="user"]')?.textContent?.trim() ||
                'Anonymous';
            const text = element.querySelector(this.commentSelector)?.textContent?.trim() ||
                element.querySelector('.message_text')?.textContent?.trim() ||
                '';
            const rowKey = element.getAttribute('data-message-id') || element.id || undefined;
            if (!text)
                return;
            if (this.isDuplicate(username, text, rowKey))
                return;
            if (Date.now() < this.bootstrapSuppressUntil) {
                return;
            }
            this.sendMessage({ username, text, timestamp: Date.now() });
        }
        catch {
            // Ignore individual element parse errors
        }
    }
}
// ============================================================
// YouTube Live Adapter
// ============================================================
class YouTubeAdapter extends BaseChatAdapter {
    constructor() {
        super(...arguments);
        this.platform = 'youtube';
    }
    canRunOnUrl(url) {
        return (url.includes('youtube.com/watch') ||
            url.includes('youtube.com/live') ||
            url.includes('youtube.com/live_chat'));
    }
    async init() {
        console.log('[youtube] Initializing YouTube Live adapter...');
        // YouTube Live chat can be in the main page or in a chat popup/iframe
        const containerSelectors = [
            '#items.yt-live-chat-item-list-renderer', // Main chat list
            'yt-live-chat-item-list-renderer #items', // Alternative selector
            '#chat-messages #items', // Older layout
            '#item-list #items', // Another variant
        ];
        try {
            const container = await this.waitForElement(containerSelectors, 60000);
            this.seedExistingMessages(container);
            this.startObserver(container);
        }
        catch (err) {
            console.error('[youtube] Failed to initialize:', err);
            // YouTube may load chat late, try observing the whole document for chat to appear
            this.watchForChatFrame();
        }
    }
    /** Watch for YouTube chat iframe/container to appear dynamically */
    watchForChatFrame() {
        console.log('[youtube] Watching for chat container to appear...');
        const docObserver = new MutationObserver(() => {
            const container = document.querySelector('#items.yt-live-chat-item-list-renderer, yt-live-chat-item-list-renderer #items');
            if (container) {
                console.log('[youtube] Chat container appeared');
                docObserver.disconnect();
                this.seedExistingMessages(container);
                this.startObserver(container);
            }
        });
        docObserver.observe(document.body, { childList: true, subtree: true });
        // Stop watching after 5 minutes
        setTimeout(() => docObserver.disconnect(), 300000);
    }
    seedExistingMessages(container) {
        const messages = container.querySelectorAll('yt-live-chat-text-message-renderer, yt-live-chat-paid-message-renderer');
        if (messages.length > 0) {
            console.log(`[youtube] Seeded ${messages.length} existing messages (skip on load)`);
            messages.forEach((msg) => {
                const element = msg;
                const username = element.querySelector('#author-name')?.textContent?.trim() || 'Anonymous';
                const text = element.querySelector('#message')?.textContent?.trim() || '';
                this.rememberExistingMessage(username, text);
            });
        }
    }
    startObserver(container) {
        this.observer = new MutationObserver((mutations) => {
            for (const mutation of mutations) {
                if (mutation.type === 'childList') {
                    mutation.addedNodes.forEach((node) => {
                        if (node.nodeType === Node.ELEMENT_NODE) {
                            const el = node;
                            // Only process actual chat message elements
                            if (el.tagName === 'YT-LIVE-CHAT-TEXT-MESSAGE-RENDERER' ||
                                el.tagName === 'YT-LIVE-CHAT-PAID-MESSAGE-RENDERER' ||
                                el.querySelector('yt-live-chat-text-message-renderer')) {
                                this.processElement(el);
                            }
                        }
                    });
                }
            }
        });
        this.observer.observe(container, { childList: true, subtree: true });
        console.log('[youtube] Observer started');
    }
    processElement(element) {
        try {
            // YouTube uses custom elements with shadow-free IDs
            const usernameEl = element.querySelector('#author-name') ||
                element.querySelector('yt-live-chat-author-chip #author-name');
            const textEl = element.querySelector('#message') ||
                element.querySelector('yt-formatted-string#message');
            const username = usernameEl?.textContent?.trim() || 'Anonymous';
            const text = textEl?.textContent?.trim() || '';
            if (!text || text.length === 0)
                return;
            if (this.isDuplicate(username, text))
                return;
            this.sendMessage({ username, text, timestamp: Date.now() });
        }
        catch {
            // Ignore individual element parse errors
        }
    }
}
// ============================================================
// Adapter Registry & Auto-Detection
// ============================================================
const ADAPTERS = [
    new NaverAdapter(),
    new YouTubeAdapter(),
];
let activeAdapter = null;
let activeUrl = '';
function shouldSkipUrl(url) {
    const parsed = new URL(url);
    // Localhost pages are usually this app itself. Only run on explicit local test page.
    const isLocalHost = parsed.hostname === 'localhost' ||
        parsed.hostname === '127.0.0.1' ||
        parsed.hostname === '[::1]';
    return isLocalHost && !parsed.pathname.includes('test-naver-chat');
}
async function detectAndInitAdapter(force = false) {
    const url = window.location.href;
    if (!force && url === activeUrl && activeAdapter) {
        return;
    }
    activeUrl = url;
    if (activeAdapter) {
        activeAdapter.cleanup();
        activeAdapter = null;
    }
    if (shouldSkipUrl(url))
        return;
    for (const adapter of ADAPTERS) {
        if (adapter.canRunOnUrl(url)) {
            activeAdapter = adapter;
            await adapter.init();
            return;
        }
    }
}
// Stamp a DOM attribute so the OnAir page can detect the extension synchronously.
document.documentElement.setAttribute('data-wendy-chat-extension', CHAT_EXTENSION_VERSION);
// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        void detectAndInitAdapter(true);
    });
}
else {
    void detectAndInitAdapter(true);
}
// Some targets use SPA-style navigation without full page reload.
let lastUrl = window.location.href;
setInterval(() => {
    if (window.location.href !== lastUrl) {
        lastUrl = window.location.href;
        void detectAndInitAdapter(true);
    }
}, 1000);
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== 'force_reinit_capture')
        return;
    void detectAndInitAdapter(true)
        .then(() => sendResponse({ success: true }))
        .catch((error) => sendResponse({
        success: false,
        error: error instanceof Error ? error.message : 'capture reinit failed',
    }));
    return true;
});
// Allow OnAir page to detect installed extension and version.
window.addEventListener('message', (event) => {
    const data = event.data;
    if (!data || data.type !== 'WENDY_CHAT_EXTENSION_PING')
        return;
    window.postMessage({
        type: 'WENDY_CHAT_EXTENSION_PONG',
        version: CHAT_EXTENSION_VERSION,
        requestId: data.requestId,
        timestamp: Date.now(),
    }, '*');
});
