"use strict";
/**
 * Background Service Worker
 * Manages WebSocket connection to backend server
 */
let ws = null;
const DEFAULT_BACKEND_URL = 'https://api.ailive.jndsolution.com';
let config = {
    backendUrl: DEFAULT_BACKEND_URL,
    sessionId: null,
    selectedChatTabId: null,
};
let reconnectAttempt = 0;
let allowAutoReconnect = true;
let isConnecting = false;
const fatalKeywords = [
    '세션',
    '인증',
    '찾을 수 없습니다',
    '비활성화',
    'not authenticated',
    'session',
    'invalid',
    'auth',
];
function patchBackgroundDebugStats(delta) {
    chrome.storage.local.get(['debugBackground'], (result) => {
        const prev = (result.debugBackground || {});
        chrome.storage.local.set({
            debugBackground: {
                receivedFromContent: (prev.receivedFromContent || 0) + (delta.receivedFromContent || 0),
                forwardedToSocket: (prev.forwardedToSocket || 0) + (delta.forwardedToSocket || 0),
                droppedNoSocket: (prev.droppedNoSocket || 0) + (delta.droppedNoSocket || 0),
                socketAcceptedCount: (prev.socketAcceptedCount || 0) + (delta.socketAcceptedCount || 0),
                socketRejectedCount: (prev.socketRejectedCount || 0) + (delta.socketRejectedCount || 0),
                inflightCount: Math.max(0, (prev.inflightCount || 0) + (delta.inflightDelta || 0)),
                socketErrorCount: (prev.socketErrorCount || 0) + (delta.socketErrorCount || 0),
                backendErrorCount: (prev.backendErrorCount || 0) + (delta.backendErrorCount || 0),
                authSuccessCount: (prev.authSuccessCount || 0) + (delta.authSuccessCount || 0),
                lastDroppedReason: delta.lastDroppedReason ?? prev.lastDroppedReason,
                lastBackendError: delta.lastBackendError ?? prev.lastBackendError,
            },
        });
    });
}
// Load config from storage on startup
chrome.storage.local.get(['backendUrl', 'sessionId', 'selectedChatTabId'], (result) => {
    config.backendUrl = result.backendUrl || DEFAULT_BACKEND_URL;
    config.sessionId = result.sessionId || null;
    config.selectedChatTabId =
        typeof result.selectedChatTabId === 'number' ? result.selectedChatTabId : null;
    // Auto-connect only when required config is ready
    if (!config.sessionId) {
        updateConnectionStatus('disconnected', '세션 ID를 입력해주세요');
    }
    else if (!config.selectedChatTabId) {
        updateConnectionStatus('disconnected', '모니터링 탭을 선택해주세요');
    }
    else {
        connectWebSocket();
    }
});
// Listen for config changes from popup
chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'local') {
        let shouldReconnectNow = false;
        if (changes.backendUrl) {
            config.backendUrl = changes.backendUrl.newValue;
            shouldReconnectNow = true;
        }
        if (changes.sessionId) {
            config.sessionId = changes.sessionId.newValue;
            shouldReconnectNow = true;
        }
        if (changes.selectedChatTabId) {
            config.selectedChatTabId =
                typeof changes.selectedChatTabId.newValue === 'number'
                    ? changes.selectedChatTabId.newValue
                    : null;
            shouldReconnectNow = true;
        }
        // If endpoint/session changed and session is configured, force reconnect immediately.
        if (shouldReconnectNow && config.sessionId && config.selectedChatTabId) {
            disconnectWebSocket();
            setTimeout(connectWebSocket, 300);
        }
        else if (shouldReconnectNow && !config.sessionId) {
            disconnectWebSocket('세션 ID를 입력해주세요');
        }
        else if (shouldReconnectNow && !config.selectedChatTabId) {
            disconnectWebSocket('모니터링 탭을 선택해주세요');
        }
    }
});
/**
 * Connect to WebSocket server
 */
function connectWebSocket() {
    if (isConnecting) {
        return;
    }
    if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) {
        return;
    }
    if (!config.sessionId) {
        updateConnectionStatus('error', '세션 ID가 설정되지 않았습니다');
        return;
    }
    if (!config.selectedChatTabId) {
        updateConnectionStatus('disconnected', '모니터링 탭을 선택해주세요');
        return;
    }
    const wsUrl = buildChatWebSocketUrl(config.backendUrl);
    try {
        isConnecting = true;
        allowAutoReconnect = true;
        updateConnectionStatus('connecting', '백엔드 연결 중...');
        ws = new WebSocket(wsUrl);
        ws.onopen = () => {
            reconnectAttempt = 0;
            isConnecting = false;
            updateConnectionStatus('connecting', '연결됨, 인증 확인 중...');
            // Authenticate
            if (ws && config.sessionId) {
                ws.send(JSON.stringify({
                    type: 'auth',
                    sessionId: config.sessionId,
                }));
            }
        };
        ws.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data);
                if (data.type === 'auth_success') {
                    updateConnectionStatus('authenticated', '인증되었습니다');
                    patchBackgroundDebugStats({
                        authSuccessCount: 1,
                        lastBackendError: '',
                        lastDroppedReason: '',
                    });
                }
                else if (data.type === 'message_received') {
                    patchBackgroundDebugStats({
                        socketAcceptedCount: 1,
                        inflightDelta: -1,
                        lastBackendError: '',
                    });
                }
                else if (data.type === 'error') {
                    const message = String(data.error || '백엔드 오류가 발생했습니다');
                    updateConnectionStatus('error', message);
                    patchBackgroundDebugStats({
                        backendErrorCount: 1,
                        socketRejectedCount: 1,
                        inflightDelta: -1,
                        lastBackendError: message,
                    });
                    // Authentication/configuration errors should not retry forever.
                    if (fatalKeywords.some((k) => message.toLowerCase().includes(k.toLowerCase()))) {
                        allowAutoReconnect = false;
                        if (ws)
                            ws.close();
                    }
                }
            }
            catch (error) {
                updateConnectionStatus('error', '백엔드 응답 형식이 올바르지 않습니다');
            }
        };
        ws.onerror = () => {
            isConnecting = false;
            updateConnectionStatus('error', '연결 오류가 발생했습니다');
            patchBackgroundDebugStats({ socketErrorCount: 1, lastDroppedReason: '웹소켓 오류' });
        };
        ws.onclose = (event) => {
            isConnecting = false;
            ws = null;
            const reason = String(event.reason || '');
            if (reason && fatalKeywords.some((k) => reason.toLowerCase().includes(k.toLowerCase()))) {
                allowAutoReconnect = false;
                updateConnectionStatus('error', reason);
            }
            // Auto-reconnect with bounded exponential backoff
            if (config.sessionId && allowAutoReconnect) {
                reconnectAttempt++;
                const delayMs = Math.min(30000, Math.pow(2, Math.min(reconnectAttempt, 5)) * 1000);
                updateConnectionStatus('connecting', `재연결 시도 중... (${Math.ceil(delayMs / 1000)}초 후)`);
                setTimeout(() => {
                    if (config.sessionId && allowAutoReconnect) {
                        connectWebSocket();
                    }
                }, delayMs);
            }
            else {
                updateConnectionStatus('disconnected', '연결이 종료되었습니다');
            }
        };
    }
    catch (error) {
        isConnecting = false;
        updateConnectionStatus('error', '연결에 실패했습니다');
    }
}
function toWebSocketBase(baseUrl) {
    if (baseUrl.startsWith('ws://') || baseUrl.startsWith('wss://'))
        return baseUrl;
    if (baseUrl.startsWith('http://'))
        return `ws://${baseUrl.slice('http://'.length)}`;
    if (baseUrl.startsWith('https://'))
        return `wss://${baseUrl.slice('https://'.length)}`;
    return `ws://${baseUrl}`;
}
function buildChatWebSocketUrl(baseUrl) {
    const wsBase = toWebSocketBase(baseUrl.trim());
    const url = new URL(wsBase);
    const basePath = url.pathname.replace(/\/+$/, '');
    const endpointPath = basePath.endsWith('/api')
        ? `${basePath}/chat/chat-extension/stream`
        : `${basePath}/api/chat/chat-extension/stream`;
    url.pathname = endpointPath;
    url.search = '';
    url.hash = '';
    return url.toString();
}
/**
 * Disconnect WebSocket
 */
function disconnectWebSocket(message = '연결이 종료되었습니다') {
    allowAutoReconnect = false;
    isConnecting = false;
    if (ws) {
        ws.close();
        ws = null;
    }
    updateConnectionStatus('disconnected', message);
}
/**
 * Update connection status in storage (for popup)
 */
function updateConnectionStatus(status, message) {
    chrome.storage.local.set({
        connectionStatus: status,
        connectionMessage: message,
        lastUpdated: new Date().toISOString(),
    });
}
function forceResetAndReconnect() {
    reconnectAttempt = 0;
    allowAutoReconnect = true;
    isConnecting = false;
    if (!config.sessionId) {
        disconnectWebSocket('세션 ID를 입력해주세요');
        return;
    }
    if (!config.selectedChatTabId) {
        disconnectWebSocket('모니터링 탭을 선택해주세요');
        return;
    }
    disconnectWebSocket('설정을 적용하는 중입니다...');
    if (config.selectedChatTabId) {
        const tabId = config.selectedChatTabId;
        chrome.tabs.sendMessage(tabId, { type: 'force_reinit_capture' }, () => {
            if (chrome.runtime.lastError) {
                // Content script not loaded on this tab — inject it programmatically
                chrome.scripting.executeScript({ target: { tabId, allFrames: true }, files: ['content.js'] }, () => void chrome.runtime.lastError);
            }
        });
    }
    setTimeout(connectWebSocket, 250);
}
/**
 * Listen for messages from content script
 */
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'chat_message') {
        if (!config.selectedChatTabId) {
            updateConnectionStatus('disconnected', '모니터링 탭을 먼저 선택해주세요');
            patchBackgroundDebugStats({
                droppedNoSocket: 1,
                lastDroppedReason: '모니터링 탭 미선택',
            });
            sendResponse({ success: false, error: '모니터링 탭을 먼저 선택해주세요' });
            return true;
        }
        if (config.selectedChatTabId && sender.tab?.id !== config.selectedChatTabId) {
            patchBackgroundDebugStats({
                droppedNoSocket: 1,
                lastDroppedReason: `선택 탭 불일치(sender=${sender.tab?.id ?? 'unknown'}, selected=${config.selectedChatTabId})`,
            });
            sendResponse({ success: false, error: '선택한 모니터링 탭이 아닙니다' });
            return true;
        }
        patchBackgroundDebugStats({ receivedFromContent: 1 });
        // Forward to WebSocket
        if (ws && ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({
                type: 'chat_message',
                username: message.username,
                text: message.text,
                platform: message.platform || 'naver',
            }));
            patchBackgroundDebugStats({ forwardedToSocket: 1, inflightDelta: 1 });
            sendResponse({ success: true });
        }
        else {
            updateConnectionStatus('disconnected', `소켓 미연결(readyState=${ws?.readyState ?? 'null'})`);
            patchBackgroundDebugStats({
                droppedNoSocket: 1,
                lastDroppedReason: `소켓 미연결(readyState=${ws?.readyState ?? 'null'})`,
            });
            sendResponse({ success: false, error: '연결되어 있지 않습니다' });
        }
        return true; // Keep channel open for async response
    }
    if (message.type === 'get_status') {
        chrome.storage.local.get(['connectionStatus', 'connectionMessage', 'debugBackground'], (result) => {
            const debugBackground = (result.debugBackground || {});
            sendResponse({
                connected: ws?.readyState === WebSocket.OPEN,
                sessionId: config.sessionId,
                selectedChatTabId: config.selectedChatTabId,
                connectionStatus: result.connectionStatus,
                connectionMessage: result.connectionMessage,
                wsReadyState: ws?.readyState ?? null,
                lastDroppedReason: debugBackground.lastDroppedReason || '',
                lastBackendError: debugBackground.lastBackendError || '',
            });
        });
        return true;
    }
    if (message.type === 'reconnect') {
        if (config.sessionId) {
            disconnectWebSocket();
            setTimeout(connectWebSocket, 1000);
            sendResponse({ success: true });
        }
        else {
            sendResponse({ success: false, error: '세션 ID가 설정되지 않았습니다' });
        }
        return true;
    }
    if (message.type === 'force_reset_and_reconnect') {
        forceResetAndReconnect();
        sendResponse({ success: true });
        return true;
    }
});
console.log('Background service worker initialized');
