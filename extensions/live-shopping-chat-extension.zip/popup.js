"use strict";
/**
 * Popup UI Script
 * Configure extension settings and view status
 */
// DOM elements
const backendUrlInput = document.getElementById('backend-url');
const sessionIdInput = document.getElementById('session-id');
const saveButton = document.getElementById('save-button');
const statusDiv = document.getElementById('status');
const statusText = document.getElementById('status-text');
const statusMessage = document.getElementById('status-message');
const platformInfo = document.getElementById('platform-info');
const platformName = document.getElementById('platform-name');
const debugContent = document.getElementById('debug-content');
const debugReset = document.getElementById('debug-reset');
const chatTabSelect = document.getElementById('chat-tab-select');
const refreshTabsButton = document.getElementById('refresh-tabs');
const naverBootstrapSuppressSecondsInput = document.getElementById('naver-bootstrap-suppress-seconds');
const PROD_BACKEND_URL = 'https://api.ailive.jndsolution.com';
const LOCAL_BACKEND_URL = 'http://localhost:4000';
// Load saved settings
chrome.storage.local.get([
    'backendUrl',
    'sessionId',
    'connectionStatus',
    'connectionMessage',
    'detectedPlatform',
    'debugContent',
    'debugBackground',
    'selectedChatTabId',
    'naverBootstrapSuppressSeconds',
], async (result) => {
    const inferredBackendUrl = await detectDefaultBackendUrlFromOpenTabs();
    backendUrlInput.value = result.backendUrl || inferredBackendUrl;
    sessionIdInput.value = result.sessionId || '';
    naverBootstrapSuppressSecondsInput.value = String(Number.isFinite(result.naverBootstrapSuppressSeconds)
        ? result.naverBootstrapSuppressSeconds
        : 5);
    void refreshLiveTabs(typeof result.selectedChatTabId === 'number' ? result.selectedChatTabId : null);
    updateStatusDisplay(result.connectionStatus, result.connectionMessage);
    updatePlatformDisplay(result.detectedPlatform);
    renderDebug(result.debugContent, result.debugBackground);
});
// Listen for status updates
chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'local') {
        if (changes.connectionStatus || changes.connectionMessage) {
            updateStatusDisplay(changes.connectionStatus?.newValue, changes.connectionMessage?.newValue);
        }
        if (changes.detectedPlatform) {
            updatePlatformDisplay(changes.detectedPlatform.newValue);
        }
        if (changes.debugContent || changes.debugBackground) {
            chrome.storage.local.get(['debugContent', 'debugBackground'], (result) => {
                renderDebug(result.debugContent, result.debugBackground);
            });
        }
    }
});
// Save button click
saveButton.addEventListener('click', () => {
    const backendUrl = backendUrlInput.value.trim();
    const sessionId = sessionIdInput.value.trim();
    const selectedChatTabId = chatTabSelect.value === '' ? null : Number.parseInt(chatTabSelect.value, 10);
    const naverBootstrapSuppressSeconds = Number.parseInt(naverBootstrapSuppressSecondsInput.value, 10);
    if (!backendUrl) {
        alert('백엔드 URL을 입력해주세요');
        return;
    }
    if (!backendUrl.startsWith('http://') &&
        !backendUrl.startsWith('https://') &&
        !backendUrl.startsWith('ws://') &&
        !backendUrl.startsWith('wss://')) {
        alert('백엔드 URL은 http(s):// 또는 ws(s):// 로 시작해야 합니다');
        return;
    }
    if (!selectedChatTabId || !Number.isFinite(selectedChatTabId)) {
        alert('모니터링할 라이브 탭을 선택해주세요');
        return;
    }
    if (!Number.isFinite(naverBootstrapSuppressSeconds) || naverBootstrapSuppressSeconds < 0) {
        alert('초기 기존 채팅 무시 시간은 0초 이상으로 입력해주세요');
        return;
    }
    // Save to storage
    chrome.storage.local.set({
        backendUrl,
        sessionId,
        selectedChatTabId: selectedChatTabId && Number.isFinite(selectedChatTabId) ? selectedChatTabId : null,
        naverBootstrapSuppressSeconds: Math.min(20, naverBootstrapSuppressSeconds),
        // Save button is treated as a full reset to recover flaky state.
        debugContent: {},
        debugBackground: {},
        detectedPlatform: '',
    }, () => {
        console.log('Settings saved, forcing reconnect');
        saveButton.textContent = '재연결 중...';
        saveButton.disabled = true;
        chrome.runtime.sendMessage({ type: 'force_reset_and_reconnect' }, () => {
            saveButton.textContent = '저장됨!';
            saveButton.classList.add('saved');
            renderDebug({}, {});
            setTimeout(() => {
                saveButton.textContent = '저장';
                saveButton.classList.remove('saved');
                saveButton.disabled = false;
            }, 1500);
        });
    });
});
debugReset.addEventListener('click', () => {
    chrome.storage.local.set({
        debugContent: {},
        debugBackground: {},
    }, () => {
        renderDebug({}, {});
    });
});
refreshTabsButton.addEventListener('click', () => {
    void refreshLiveTabs();
});
/**
 * Update platform display
 */
function updatePlatformDisplay(platform) {
    if (platform) {
        const names = {
            naver: 'Naver',
            youtube: 'YouTube',
        };
        platformName.textContent = names[platform] || platform;
        platformInfo.style.display = 'inline-flex';
    }
    else {
        platformInfo.style.display = 'none';
    }
}
/**
 * Update status display
 */
function updateStatusDisplay(status, message) {
    if (!status)
        return;
    statusDiv.className = `status ${status}`;
    switch (status) {
        case 'connecting':
            statusText.textContent = '연결 중';
            break;
        case 'connected':
            statusText.textContent = '연결됨';
            break;
        case 'authenticated':
            statusText.textContent = '인증됨';
            break;
        case 'disconnected':
            statusText.textContent = '연결 끊김';
            break;
        case 'error':
            statusText.textContent = '오류';
            break;
        default:
            statusText.textContent = status;
    }
    if (message) {
        statusMessage.textContent = message;
        statusMessage.style.display = 'block';
    }
    else {
        statusMessage.style.display = 'none';
    }
}
function fmt(ts) {
    if (!ts)
        return '-';
    const d = new Date(ts);
    if (Number.isNaN(d.getTime()))
        return '-';
    return d.toLocaleTimeString();
}
function renderDebug(content, background) {
    const c = content || {};
    const b = background || {};
    debugContent.textContent = [
        `감지: ${c.detectedCount || 0} / 중복: ${c.duplicateCount || 0}`,
        `전송 성공: ${c.sentCount || 0} / 전송 실패: ${c.sendFailedCount || 0}`,
        `백그라운드 수신: ${b.receivedFromContent || 0} / 소켓전달: ${b.forwardedToSocket || 0} / 드롭: ${b.droppedNoSocket || 0}`,
        `서버 수신확정(ACK): ${b.socketAcceptedCount || 0} / 서버 거절: ${b.socketRejectedCount || 0} / 전송대기: ${b.inflightCount || 0}`,
        `인증 성공: ${b.authSuccessCount || 0} / 소켓 오류: ${b.socketErrorCount || 0} / 백엔드 오류: ${b.backendErrorCount || 0}`,
        `마지막 감지: ${fmt(c.lastDetectedAt)} / 마지막 전송: ${fmt(c.lastSentAt)}`,
        `최근 오류: ${c.lastError || b.lastBackendError || b.lastDroppedReason || '-'}`,
    ].join('\n');
}
function isSupportedLiveUrl(url) {
    if (!url)
        return false;
    return (url.includes('shoppinglive.naver.com') ||
        url.includes('youtube.com/watch') ||
        url.includes('youtube.com/live') ||
        url.includes('youtube.com/live_chat') ||
        url.includes('test-naver-chat'));
}
function isProdAiliveUrl(url) {
    if (!url)
        return false;
    try {
        const parsed = new URL(url);
        const hostname = parsed.hostname.toLowerCase();
        return hostname === 'ailive.jndsolution.com' || hostname.endsWith('.ailive.jndsolution.com');
    }
    catch {
        return false;
    }
}
function detectDefaultBackendUrlFromOpenTabs() {
    return new Promise((resolve) => {
        chrome.tabs.query({}, (tabs) => {
            if (chrome.runtime.lastError) {
                resolve(PROD_BACKEND_URL);
                return;
            }
            const hasProdTab = tabs.some((tab) => isProdAiliveUrl(tab.url));
            resolve(hasProdTab ? PROD_BACKEND_URL : LOCAL_BACKEND_URL);
        });
    });
}
function formatTabLabel(tab) {
    const title = (tab.title || '(제목 없음)').trim();
    const url = (tab.url || '').trim();
    const shortUrl = url.length > 60 ? `${url.slice(0, 57)}...` : url;
    return `${title} — ${shortUrl}`;
}
function queryLiveTabs() {
    return new Promise((resolve) => {
        chrome.tabs.query({}, (tabs) => {
            const options = tabs
                .filter((tab) => typeof tab.id === 'number' && isSupportedLiveUrl(tab.url))
                .map((tab) => ({
                id: tab.id,
                label: formatTabLabel(tab),
            }));
            resolve(options);
        });
    });
}
async function refreshLiveTabs(selectedId) {
    const liveTabs = await queryLiveTabs();
    chatTabSelect.innerHTML = '';
    const anyOption = document.createElement('option');
    anyOption.value = '';
    anyOption.textContent = '모니터링 탭을 선택하세요';
    chatTabSelect.appendChild(anyOption);
    for (const tab of liveTabs) {
        const option = document.createElement('option');
        option.value = String(tab.id);
        option.textContent = tab.label;
        chatTabSelect.appendChild(option);
    }
    if (selectedId && liveTabs.some((t) => t.id === selectedId)) {
        chatTabSelect.value = String(selectedId);
        return;
    }
    if (typeof selectedId === 'number' && selectedId > 0) {
        // Keep stale selection visible so user knows previous tab is gone.
        const stale = document.createElement('option');
        stale.value = String(selectedId);
        stale.textContent = `이전 선택 탭(ID: ${selectedId}) - 현재 없음`;
        chatTabSelect.appendChild(stale);
        chatTabSelect.value = String(selectedId);
    }
    else {
        chatTabSelect.value = '';
    }
}
// Request status update on popup open
chrome.runtime.sendMessage({ type: 'get_status' }, (response) => {
    if (response) {
        const status = response.connectionStatus || (response.connected ? 'authenticated' : 'disconnected');
        const message = response.connectionMessage ||
            response.lastBackendError ||
            response.lastDroppedReason ||
            (!response.sessionId
                ? '세션 ID를 입력해주세요'
                : !response.selectedChatTabId
                    ? '모니터링 탭을 선택해주세요'
                    : `소켓 상태 확인 필요(readyState=${response.wsReadyState ?? 'null'})`);
        updateStatusDisplay(status, message);
        void refreshLiveTabs(typeof response.selectedChatTabId === 'number' ? response.selectedChatTabId : null);
    }
});
console.log('Popup script loaded');
